angular.module('app.controllers', [])
  
.controller('EReminderCtrl', function($scope) {

})
 